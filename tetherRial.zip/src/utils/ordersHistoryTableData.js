const ordersHistoryTableData = [
  {
    id: 0,
    tracking: null,
    status: true,
  },
  {
    id: 1,
    tracking: null,
    status: false,
  },
  {
    id: 2,
    tracking: "TXID",
    status: false,
  },
  {
    id: 3,
    tracking: null,
    status: true,
  },
  {
    id: 4,
    tracking: null,
    status: false,
  },
  {
    id: 5,
    tracking: "TXID",
    status: true,
  },
  {
    id: 6,
    tracking: null,
    status: false,
  },
];

export default ordersHistoryTableData;
