const myOrdersTableData = [
  {
    id: 0,
    networkType: "شبکه اتریوم",
    status: "checking",
  },
  {
    id: 1,
    networkType: "فروش",
    status: "sending",
  },
  {
    id: 2,
    networkType: "فروش",
    status: "checking",
  },
  {
    id: 3,
    networkType: "شبکه اتریوم",
    status: "sending",
  },
  {
    id: 4,
    totalPrice: "۳۴۵.۶۶۶.۸۶۴",
    networkType: "فروش",
    status: "sending",
  },
  {
    id: 5,
    totalPrice: "۳۴۵.۶۶۶.۸۶۴",
    networkType: "شبکه اتریوم",
    status: "checking",
  },
  {
    id: 6,
    totalPrice: "۳۴۵.۶۶۶.۸۶۴",
    networkType: "شبکه اتریوم",
    status: "checking",
  },
];

export default myOrdersTableData;
