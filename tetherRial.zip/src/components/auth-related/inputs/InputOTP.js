import React from "react";
import "./css/InputOTP.css";

const InputOTP = () => {
  return (
    <div className="flex input-otp-container">
      <input type="text" />
      <input type="text" />
      <input type="text" />
      <input type="text" />
      <input type="text" />
      <input type="text" />
    </div>
  );
};

export default InputOTP;
